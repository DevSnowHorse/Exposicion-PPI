# Mi Arepa Web - Arepas El Cuñado

## Archivos
- `index.html`: estructura de la aplicación.
- `css/styles.css`: estilos y diseño adaptable.
- `js/app.js`: interacciones y datos de demostración en localStorage.
- `java/MiArepaWeb.java`: ejemplo académico de lógica básica en Java.

## Cómo ejecutar
1. Descomprime la carpeta.
2. Abre `index.html` en Google Chrome, Edge o Firefox.
3. Inicia sesión con uno de los usuarios de demostración.

## Usuarios de demostración
Todos usan la contraseña `123456`:
- Administrador: `admin@arepas.com`
- Gerente: `gerente@arepas.com`
- Vendedor: `vendedor@arepas.com`
- Operario de bodega: `bodega@arepas.com`

## Funcionalidades de esta versión
- Inicio de sesión por rol (roles y permisos de navegación de demostración).
- Panel principal con indicadores, pedidos recientes y alertas de stock.
- Registro, edición y búsqueda de clientes.
- Registro de pedidos con validación de stock y cálculo de totales.
- Actualización de estado de pedidos.
- Entradas y salidas de inventario con validación.
- Registro de lotes de producción y actualización de inventario.
- Generación e impresión de factura.
- Reporte de ventas CSV.
- Gestión básica de usuarios y descarga de respaldo JSON.
- Catálogo visual de arepas, desayunos y almuerzos.

## Importante para la entrega académica
Esta es una versión demostrativa front-end: guarda los datos en el almacenamiento local del navegador (`localStorage`). Los cambios quedan guardados en el mismo navegador y equipo, pero no se sincronizan entre usuarios o dispositivos. La autenticación de esta maqueta es para demostración, no seguridad de producción.

El archivo Java contiene clases básicas de ejemplo para Producto y Pedido, pero no está conectado al navegador. Para una solución multiusuario real, el proyecto del documento plantea una API Java/Spring Boot y base de datos MySQL; eso requiere configurar el backend, endpoints, base de datos y autenticación segura.

Las fotografías del catálogo se cargan desde Unsplash, por lo que se necesita conexión a internet para verlas.
