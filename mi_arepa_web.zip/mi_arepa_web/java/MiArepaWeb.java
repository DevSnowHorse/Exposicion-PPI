package com.arepaselcunado;

import java.util.ArrayList;
import java.util.List;

/**
 * Ejemplo básico de lógica de negocio para Mi Arepa Web.
 * Este archivo es una base académica en Java puro; no está conectado
 * automáticamente con la interfaz HTML/JavaScript.
 */
public class MiArepaWeb {
    static class Producto {
        private String nombre;
        private int stock;
        private int stockMinimo;
        private double precio;

        public Producto(String nombre, int stock, int stockMinimo, double precio) {
            this.nombre = nombre;
            this.stock = stock;
            this.stockMinimo = stockMinimo;
            this.precio = precio;
        }

        public String getNombre() { return nombre; }
        public int getStock() { return stock; }
        public int getStockMinimo() { return stockMinimo; }
        public double getPrecio() { return precio; }

        public void entrada(int cantidad) {
            if (cantidad <= 0) throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
            stock += cantidad;
        }

        public void salida(int cantidad) {
            if (cantidad <= 0 || cantidad > stock)
                throw new IllegalArgumentException("Cantidad inválida o stock insuficiente.");
            stock -= cantidad;
        }

        public boolean tieneStockBajo() {
            return stock <= stockMinimo;
        }
    }

    static class ItemPedido {
        Producto producto;
        int cantidad;

        ItemPedido(Producto producto, int cantidad) {
            this.producto = producto;
            this.cantidad = cantidad;
        }

        double subtotal() {
            return producto.getPrecio() * cantidad;
        }
    }

    static class Pedido {
        private String codigo;
        private String cliente;
        private List<ItemPedido> items = new ArrayList<>();
        private String estado = "Registrado";

        Pedido(String codigo, String cliente) {
            this.codigo = codigo;
            this.cliente = cliente;
        }

        public void agregarProducto(Producto producto, int cantidad) {
            if (cantidad <= 0 || producto.getStock() < cantidad)
                throw new IllegalArgumentException("No hay stock suficiente para " + producto.getNombre());
            items.add(new ItemPedido(producto, cantidad));
        }

        public double calcularTotal() {
            double total = 0;
            for (ItemPedido item : items) total += item.subtotal();
            return total;
        }

        public void confirmar() {
            if (items.isEmpty()) throw new IllegalStateException("El pedido no tiene productos.");
            estado = "Confirmado";
        }

        public String getCodigo() { return codigo; }
        public String getCliente() { return cliente; }
        public String getEstado() { return estado; }
    }

    public static void main(String[] args) {
        Producto arepaBlanca = new Producto("Arepa de maíz blanco", 180, 30, 18000);
        Pedido pedido = new Pedido("PED-0001", "Supermercado El Ahorro");

        pedido.agregarProducto(arepaBlanca, 10);
        pedido.confirmar();

        System.out.println("Pedido: " + pedido.getCodigo());
        System.out.println("Cliente: " + pedido.getCliente());
        System.out.println("Estado: " + pedido.getEstado());
        System.out.println("Total: $" + pedido.calcularTotal());

        if (arepaBlanca.tieneStockBajo()) {
            System.out.println("ALERTA: stock mínimo de " + arepaBlanca.getNombre());
        }
    }
}
